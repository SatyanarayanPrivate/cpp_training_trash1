﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Threading;

class ObserverPattern
{

    class Subscriber
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public Subscriber(string name, string email)
        {
            this.Name = name;
            this.Email = email;
        }
    }

    class BlogSubscribers : IEnumerable
    {
        Subscriber[] Arrays = { new Subscriber("user1", "firstEmail@gmail.com"), new Subscriber("user2", "2ndEmail@gmail.com") };

        public IEnumerator GetEnumerator()
        {
            foreach (Subscriber element in Arrays)
                yield return element;
        }
    }

    public delegate void Callback(String subscriber);
    class Subject
    {
        //Declaring delegate 
        Dictionary<string, Callback> Notify = new Dictionary<string, Callback>();
        //Declaring Event 
        // List of Users as IEnumerable
        BlogSubscribers blogSubscribers = new BlogSubscribers();

        /// <summary>
        /// Attaching the events
        /// </summary>
        /// <param name="subscriber">its the name of user or email address</param>
        /// <param name="Update">A method to attach </param>
        public void Attach(string subscriber, Callback Update)
        {
            if (!Notify.ContainsKey(subscriber))
            {
                Notify[subscriber] = delegate { };
            }

            Notify[subscriber] += Update;
        }
        /// <summary>
        /// To Detach method for specific user
        /// </summary>
        /// <param name="subscriber">its the name of user or email address</param>
        /// <param name="Update">A method to attach</param>
        public void Detach(string subscriber, Callback Update)
        {

            Notify[subscriber] -= Update;
        }
        /// <summary>
        /// Loop through all users to notify for anychange
        /// </summary>
        public void Run()
        {
            foreach (Subscriber subscriber in blogSubscribers)
            {
                string message = string.Format(" To {0}<{1}> ", subscriber.Name, subscriber.Email);
                Notify[subscriber.Name](message);
            }
        }
    }

    interface IObserver
    {
        void Update(string message);
    }
    class BlogPost
    {
        public string PostName { get; set; }

    }
    class BlogObserver : IObserver
    {
        //name of the posting

        // Implmenting through IOC Inversion of control 
        Subject subject;
        List<BlogPost> ListOfBlogNewPosts = new List<BlogPost>();
        public BlogObserver(Subject subject)
        {
            this.subject = subject;
            subject.Attach("user1", Update);
            subject.Attach("user2", Update);

        }
        public void AddPost(BlogPost blogPost)
        {
            ListOfBlogNewPosts.Add(blogPost);
        }

        public void Update(string message)
        {
            foreach (BlogPost blogPost in ListOfBlogNewPosts)
            {
                Console.WriteLine("--------------------- New Posting ---------------------");
                Console.WriteLine(" {0} for Post {1}", message, blogPost.PostName);
                Console.WriteLine();
            }
        }
        public void DetachFromPost(string subscriber)
        {
            subject.Detach(subscriber, Update);
        }
    }

    public class BlogFacade
    {
        public static void PublishMultiPost()
        {
            Subject subject = new Subject();
            BlogPost Ps3 = new BlogPost();
            Ps3.PostName = "PS3";
            BlogPost Xbox = new BlogPost();
            Xbox.PostName = "Xbox";
            BlogObserver salmanBlog = new BlogObserver(subject);
            salmanBlog.AddPost(Ps3);
            salmanBlog.AddPost(Xbox);
            //lets try to detach users2 from the subscriber list  for posting xbox
            //salmanBlog.DetachFromPost("user2");
            subject.Run();
        }
        public static void PublishSinglePost()
        {
            Subject subject = new Subject();
            BlogPost Xbox = new BlogPost();
            Xbox.PostName = "Xbox";
            BlogObserver salmanBlog = new BlogObserver(subject);
            salmanBlog.AddPost(Xbox);
            subject.Run();
        }

    }

    static void Main()
    {
        //BlogFacade.PublishSinglePost();
        BlogFacade.PublishMultiPost();
    }
}


