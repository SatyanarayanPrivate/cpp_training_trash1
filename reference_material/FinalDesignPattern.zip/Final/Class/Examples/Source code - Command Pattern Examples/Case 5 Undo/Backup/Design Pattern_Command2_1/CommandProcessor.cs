﻿using System.Collections.Generic;
namespace Design_Pattern_Command2_1
{
    //Command hooked class - the invoker class
    class CommandProcessor
    {
        List<Command> allHookedCommandsList = new List<Command>();
        Stack<UndoableCommand> undoCommandsStack = new Stack<UndoableCommand>();
        
        private Command newCmd;
        public Command NewCmd
        {
            get { return newCmd; }
            set 
            { 
                newCmd = value;
                if (newCmd != null)
                {
                    allHookedCommandsList.Add(newCmd);
                }
            }
        }

        private Command openCmd;
        public Command OpenCmd
        {
            get { return openCmd; }
            set
            {
                openCmd = value;
                if (openCmd != null)
                    allHookedCommandsList.Add(openCmd);
            }
        }

        private Command saveCmd;
        public Command SaveCmd
        {
            get { return saveCmd; }
            set
            {
                saveCmd = value;
                if (saveCmd != null)
                    allHookedCommandsList.Add(saveCmd);
            }
        }

        private Command printCmd;
        public Command PrintCmd
        {
            get { return printCmd; }
            set
            {
                printCmd = value;
                if (printCmd != null)
                    allHookedCommandsList.Add(printCmd);
            }
        }       
        
        public void RunCommands()
        {
            foreach (Command hookedCommand in allHookedCommandsList)
            {
                if (hookedCommand is UndoableCommand)
                    undoCommandsStack.Push((UndoableCommand)hookedCommand);
                hookedCommand.Execute();
            }            
        }

        public void Undo()
        {
            UndoableCommand lastUndoableCmd;
            if (undoCommandsStack.Count > 0)
            {
                lastUndoableCmd = undoCommandsStack.Pop();
                lastUndoableCmd.UnExecute();
                allHookedCommandsList.Remove(lastUndoableCmd);
            }
        }
    }
}
