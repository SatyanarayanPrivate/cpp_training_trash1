﻿namespace Design_Pattern_Command2_1
{
    public abstract class Command
    {
        public abstract void Execute();
    }

    public abstract class UndoableCommand : Command
    {
        public abstract void UnExecute();
    }

    //Encapsulate Server.New() request
    public class NewCommand : Command
    {
        Server targetObj;
        public NewCommand(Server targetObjInstance)
        {
            targetObj = targetObjInstance;
        }

        public override void Execute()
        {
            targetObj.New();
        }
    }

    //Encapsulate Server.Open() request
    public class OpenCommand : Command
    {
        Server targetObj;
        public OpenCommand(Server targetObjInstance)
        {
            targetObj = targetObjInstance;
        }

        public override void Execute()
        {
            targetObj.Open();
        }
    }

    //Encapsulate Server.Save() request
    public class SaveCommand : Command
    {
        Server targetObj;
        public SaveCommand(Server targetObjInstance)
        {
            targetObj = targetObjInstance;
        }

        public override void Execute()
        {
            targetObj.Save();
        }
    }

    //This command is capable of encapsulation two receiver actions.
    //Request 1: Server.Print(string message)
    //Request 2: Server.UndoPrint()
    //Request 2 implementation = Undo Request 1
    public class PrintCommand : UndoableCommand
    {
        Server targetObj;
        public string Parameter {get; set;}
        public PrintCommand(Server targetObjInstance)
        {
            targetObj = targetObjInstance;
        }

        public override void Execute()
        {
            targetObj.Print(Parameter);
        }

        public override void UnExecute()
        {
            targetObj.UndoPrint();
        }
    }

}
