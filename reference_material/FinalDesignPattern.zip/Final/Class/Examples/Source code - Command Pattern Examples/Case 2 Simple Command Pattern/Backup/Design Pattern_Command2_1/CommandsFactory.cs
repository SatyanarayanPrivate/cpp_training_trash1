﻿namespace Design_Pattern_Command2_1
{
    //Decouples client from creating concrete command instances.
    public class CommandsFactory
    {
        static Server targetObject;
        static NewCommand newCmd;
        static OpenCommand openCmd;
        static SaveCommand saveCmd;
        static PrintCommand printCmd;

        static CommandsFactory()
        {
            targetObject = new Server();
            newCmd = new NewCommand(targetObject);
            openCmd = new OpenCommand(targetObject);
            saveCmd = new SaveCommand(targetObject);
            printCmd = new PrintCommand(targetObject);
            printCmd.Parameter = "Hi";
        }
        public static Command GetCommand(string commandType)
        {
            switch (commandType.ToUpper())
            {
                case "NEW": return newCmd;
                case "OPEN": return openCmd;
                case "SAVE": return saveCmd;
                case "PRINT": return printCmd;
                default: return newCmd;
            }
        }
    }
}
