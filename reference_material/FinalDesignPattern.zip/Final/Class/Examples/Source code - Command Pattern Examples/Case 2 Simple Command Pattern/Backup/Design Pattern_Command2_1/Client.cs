﻿using System;

namespace Design_Pattern_Command2_1
{
    //Pushing only one time real commands into commandprocessor to let it service other ServiceTakingClient or self.
    class Client
    {
        static void Main(string[] args)
        {
            CommandProcessor cmdProcessor = new CommandProcessor();
            //CommandProcessor should not be aware about actual command instances. It should be assigned to by the Client
            cmdProcessor.NewCmd = CommandsFactory.GetCommand("NEW");//Using CommandsFactory Client is indirectly creating command instances.
            cmdProcessor.OpenCmd = CommandsFactory.GetCommand("OPEN");
            cmdProcessor.SaveCmd = CommandsFactory.GetCommand("SAVE");
            cmdProcessor.PrintCmd = CommandsFactory.GetCommand("PRINT");
            ServiceTakingClient actualClientObj = new ServiceTakingClient(cmdProcessor);
            actualClientObj.Do();//
            Console.ReadLine();
        }
    }
    
    //Service taker. 
    //Service taking client can be different from actual command creating clients 
    //which also creates the instance of commandprocessor(invoker) object.
    class ServiceTakingClient
    {
        CommandProcessor cmdProcessor;
        public ServiceTakingClient(CommandProcessor cmdProcessor)
        {
            this.cmdProcessor = cmdProcessor;
        }

        public void Do()
        {
            cmdProcessor.RunCommands();
        }

    }
}
