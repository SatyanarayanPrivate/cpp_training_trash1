﻿using System;

namespace Design_Pattern_Command2
{
    public class Server
    {
        public void New()
        {
            Console.WriteLine("Server.New(): New file created.");
        }

        public void Open()
        {
            Console.WriteLine("Server.Open(): Existing file opened.");
        }

        public void Save()
        {
            Console.WriteLine("Server.Save(): Current file saved.");
        }

        public void Print(string message)
        {
            Console.WriteLine("Server.Print(): " + message);
        }
    }
}
