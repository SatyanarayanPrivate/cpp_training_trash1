﻿namespace Design_Pattern_Command2
{
    class Client
    {
        public void Do()
        {
            Server serverObj = new Server();
            serverObj.New(); //Want to create new file
            serverObj.Open(); //Want to open existing file
            serverObj.Save(); //Want to save current file
            serverObj.Print("Hi!"); //Want to print some message
        }
    }
}
