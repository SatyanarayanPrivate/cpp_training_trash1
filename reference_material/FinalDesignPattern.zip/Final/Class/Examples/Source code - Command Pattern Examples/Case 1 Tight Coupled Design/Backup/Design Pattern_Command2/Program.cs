﻿using System;

namespace Design_Pattern_Command2
{
    class Program
    {
        static void Main(string[] args)
        {
            Client clientObj = new Client();
            clientObj.Do();
            Console.ReadLine();
        }
    }
}
