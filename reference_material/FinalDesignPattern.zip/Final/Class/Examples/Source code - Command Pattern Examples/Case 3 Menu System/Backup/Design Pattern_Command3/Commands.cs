﻿namespace Design_Pattern_Command3
{
    public abstract class Command
    {
        public abstract void Execute();
    }

    //Encapsulate Server.New() request
    public class NewCommand : Command
    {
        Server targetObj;
        public NewCommand(Server targetObjInstance)
        {
            targetObj = targetObjInstance;
        }

        public override void Execute()
        {
            targetObj.New();
        }
    }

    //Encapsulate Server.Open() request
    public class OpenCommand : Command
    {
        Server targetObj;
        public OpenCommand(Server targetObjInstance)
        {
            targetObj = targetObjInstance;
        }

        public override void Execute()
        {
            targetObj.Open();
        }
    }
}
