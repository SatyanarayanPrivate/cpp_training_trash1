﻿namespace Design_Pattern_Command3
{
    //Using command encapsultation
    public class CommandsFactory
    {
        static Server targetObject;
        static NewCommand newCmd;
        static OpenCommand openCmd;

        static CommandsFactory()
        {
            targetObject = new Server();
            newCmd = new NewCommand(targetObject);
            openCmd = new OpenCommand(targetObject);
        }
        public static Command GetCommand(string commandType)
        {
            switch (commandType.ToUpper())
            {
                case "NEW": return newCmd;
                case "OPEN": return openCmd;
                default: return newCmd;
            }
        }
    }
}
