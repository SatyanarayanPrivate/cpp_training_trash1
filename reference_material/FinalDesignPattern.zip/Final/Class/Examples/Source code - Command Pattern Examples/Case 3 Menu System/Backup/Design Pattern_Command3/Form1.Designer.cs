﻿using System;
using System.Windows.Forms;
namespace Design_Pattern_Command3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.newToolStripMenuItem = new CmdToolStripMenuItem();
            this.openToolStripMenuItem = new CmdToolStripMenuItem();
            this.btn_New = new CmdButton();
            this.btn_Open = new CmdButton();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(132, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.newToolStripMenuItem.Text = "New";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.openToolStripMenuItem.Text = "Open";
            // 
            // btn_New
            // 
            this.btn_New.Location = new System.Drawing.Point(12, 37);
            this.btn_New.Name = "btn_New";
            this.btn_New.Size = new System.Drawing.Size(42, 23);
            this.btn_New.TabIndex = 1;
            this.btn_New.Text = "New";
            this.btn_New.UseVisualStyleBackColor = true;
            // 
            // btn_Open
            // 
            this.btn_Open.Location = new System.Drawing.Point(77, 37);
            this.btn_Open.Name = "btn_Open";
            this.btn_Open.Size = new System.Drawing.Size(42, 23);
            this.btn_Open.TabIndex = 2;
            this.btn_Open.Text = "Open";
            this.btn_Open.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(132, 72);
            this.Controls.Add(this.btn_Open);
            this.Controls.Add(this.btn_New);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Editor";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private CmdToolStripMenuItem newToolStripMenuItem;
        private CmdToolStripMenuItem openToolStripMenuItem;
        private CmdButton btn_New;
        private CmdButton btn_Open;
    }

    public class CmdToolStripMenuItem : ToolStripMenuItem
    {
        private Command _command;

        public CmdToolStripMenuItem()
            : base()
        {
            this.Click += new EventHandler(CmdMenuItemClick);
            _command = null;
        }

        public Command HookedCommand
        {
            get { return _command; }
            set { _command = value; }
        }

        private void CmdMenuItemClick(object sender, EventArgs args)
        {
            if (_command != null) _command.Execute();
        }
    }

    public class CmdButton : Button
    {
        private Command _command;

        public CmdButton()
            : base()
        {
            this.Click += new EventHandler(CmdButtonClick);
            _command = null;
        }

        public Command HookedCommand
        {
            get { return _command; }
            set { _command = value; }
        }

        private void CmdButtonClick(object sender, EventArgs args)
        {
            if (_command != null) _command.Execute();
        }
    }


}

