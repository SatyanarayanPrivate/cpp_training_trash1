﻿using System.Windows.Forms;

namespace Design_Pattern_Command3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            newToolStripMenuItem.HookedCommand = CommandsFactory.GetCommand("NEW");
            btn_New.HookedCommand = CommandsFactory.GetCommand("NEW");
            openToolStripMenuItem.HookedCommand = CommandsFactory.GetCommand("OPEN");
            btn_Open.HookedCommand = CommandsFactory.GetCommand("OPEN");
        }      
    }
}
