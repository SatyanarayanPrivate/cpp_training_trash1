﻿using System;
using System.Windows.Forms;

namespace Design_Pattern_Command3
{
    public class Server
    {
        public void New()
        {
            MessageBox.Show("Server.New(): New file created");
        }

        public void Open()
        {
            MessageBox.Show("Server.Open(): Existing file opened");
        }
    }
}
