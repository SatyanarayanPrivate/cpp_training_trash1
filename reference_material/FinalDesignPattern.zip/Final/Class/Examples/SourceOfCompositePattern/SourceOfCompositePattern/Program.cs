﻿/// <summary>
/// The 'Component' Treenode
/// </summary>
using System;
using System.Collections;
using System.Collections.Generic;
public interface IEmployed
{
 int EmpID { get; set; }
 string Name { get; set; }
}
 
/// <summary>
/// The 'Composite' class
/// </summary>
public class Employee : IEmployed, IEnumerable<IEmployed>
{
 private List<IEmployed> _subordinates = new List<IEmployed>();
 
 public int EmpID { get; set; }
 public string Name { get; set; }

 public void AddSubordinate(IEmployed subordinate)
 {
 _subordinates.Add(subordinate);
 }
 
 public void RemoveSubordinate(IEmployed subordinate)
 {
 _subordinates.Remove(subordinate);
 }
 
 public IEmployed GetSubordinate(int index)
 {
 return _subordinates[index];
 }
 
 public IEnumerator<IEmployed> GetEnumerator()
 {
 foreach (IEmployed subordinate in _subordinates)
 {
 yield return subordinate;
 }
 }
 
 IEnumerator IEnumerable.GetEnumerator()
 {
 return GetEnumerator();
 }
}
 
/// <summary>
/// The 'Leaf' class
/// </summary>
public class Contractor : IEmployed
{
 public int EmpID { get; set; }
 public string Name { get; set; }
}
 
class Program
{
 static void Main(string[] args)
 {
 Employee Vivian = new Employee { EmpID = 1, Name = "Vivian" };
 
 Employee Marshal = new Employee { EmpID = 2, Name = "Marshal" };
 Employee Ambrose = new Employee { EmpID = 3, Name = "Ambrose" };
 
 Vivian.AddSubordinate(Marshal);
 Vivian.AddSubordinate(Ambrose);
 
 Employee Lara = new Employee { EmpID = 4, Name = "Lara" };
 Employee Simmons = new Employee { EmpID = 5, Name = "Simmons" };
 
 Marshal.AddSubordinate(Lara);
 Marshal.AddSubordinate(Simmons);
 
 Employee Gayle = new Employee { EmpID = 6, Name = "Gayle" };
 Employee Pollard = new Employee { EmpID = 7, Name = "Pollard" };
 
Contractor Bishop = new Contractor { EmpID = 8, Name = "Bishop" };
 Contractor Walsh = new Contractor { EmpID = 9, Name = "Walsh" };
 
 Ambrose.AddSubordinate(Gayle);
 Ambrose.AddSubordinate(Pollard);
 Ambrose.AddSubordinate(Bishop);
 Ambrose.AddSubordinate(Walsh);
 
 Console.WriteLine("EmpID={0}, Name={1}", Vivian.EmpID, Vivian.Name);
 
 foreach (Employee manager in Vivian)
 {
 Console.WriteLine("\n EmpID={0}, Name={1}", manager.EmpID, manager.Name);
 
 foreach (var employee in manager)
 {
 Console.WriteLine(" \t EmpID={0}, Name={1}", employee.EmpID, employee.Name);
 }
 }
 Console.ReadKey();
 }
}
